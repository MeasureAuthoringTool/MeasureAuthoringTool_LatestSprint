import java.util.ArrayList;
import java.util.List;
import java.util.Stack;


public class ANSV<T extends Comparable<? super T>> {

	/* Each entry
	 	anavlVal
		ansvlPos
		ansvrVal
		ansvrPos
	 */
	
	
	private Integer min = null;
	private Integer max = null;
	//private Object UNKNOWN = null;
	
	public List<T> ansvl(List<T>in ){
		 List<T> out = new ArrayList<T>();
		 Stack<T> st = new Stack<T>();
		 for(T i: in){
			 while(!st.empty() && st.peek().compareTo(i) >= 0){
				 st.pop();
			 }
			 if(st.empty())
				 out.add(null);
			 else
				 out.add(st.peek());
			 st.push(i);
		 }
		 return out;
	}
	
	
	public List<Integer> ansvl_index(List<T>in ){
		 List<Integer> out = new ArrayList<Integer>();
		 Stack<T> st = new Stack<T>();
		 Stack<Integer> st_index = new Stack<Integer>();
		 for(int i=0;i<in.size();i++){
			 while(!st.empty() && st.peek().compareTo(in.get(i))>=0){
				 st.pop();
				 st_index.pop();
			 }
			 if(st.empty())
				 out.add(null);
			 else
				 out.add(st_index.peek());
			 st.push(in.get(i));
			 st_index.push(i);
		 }
		 return out;
	}
	
	
	
	public List<T> ansvr(List<T>in ){
		 List<T> out = new ArrayList<T>();
		 Stack<T> st = new Stack<T>();
		 for(int i= in.size()-1; i>=0;i--){
			 while(!st.empty() && st.peek().compareTo(in.get(i))>=0){
				 st.pop();
			 }
			 if(st.empty())
				 out.add(null);
			 else
				 out.add(st.peek());
			 st.push(in.get(i));
		 }
		 return out;
	}
	
	
	public List<Integer> ansvr_index(List<T>in ){
		 List<Integer> out = new ArrayList<Integer>();
		 Stack<T> st = new Stack<T>();
		 Stack<Integer> st_index = new Stack<Integer>();
		 for(int i= in.size()-1; i>=0;i--){
			 while(!st.empty() && st.peek().compareTo(in.get(i))>=0){
				 st.pop();
				 st_index.pop();
			 }
			 if(st.empty())
				 out.add(null);
			 else
				 out.add(st_index.peek());
			 st.push(in.get(i));
			 st_index.push(i);
		 }
		 return out;
	}
	
	
	
	/*
	[e,c,m,i][q,k,s,f][w,g,a,y][o,v,x,b][r,n,h,z][u,d,t,p][j,l]
	
min [c0]      [f1]      [a2]      [b3]      [n4]      [d5]      [j6]
	
	      [c0]            [a2]                [d5]           [j6]
	              [a2]                               [d5]
	                               [a2]    
	
	
	*/
}
