import java.util.Arrays;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;


public class WordArrayAlgs {
	
	
	static void scan(int[] src, int[] dest){
		int i;
		dest[0]=src[0];
		for(i=1;i < src.length; i++)
			dest[i]= dest[i-1]+ src[i];
	}
	
	private static int TRIALS = 10;
	
	//Still need to handle last few elements
	static void scan_unroll4(int[] src, int[] dest){
		int i;
		int r0,r1,r2,r3;
		int current;
		dest[0]=src[0];
		dest[1]=dest[0]+src[1];
		dest[2]=dest[1]+src[2];
		dest[3]=dest[2]+src[3];
		current = dest[3];
		for(i=1;i < src.length/4; i++){
			
			r0=src[i*4]+current;
			r1=src[i*4+1]+r0;
			r2=src[i*4+2]+r1;
			current=r3=src[i*4+3]+r2;
			
			dest[i*4]= r0;
			dest[i*4+1]= r1;
			dest[i*4+2]= r2;
			dest[i*4+3]= r3;
		}
	}
	
	private static void myArrayCopy(int[] src, int[]dest){
		int i;
		dest[src.length-1]=src[src.length-1];
		for(i=0;i<src.length ; i++)
			dest[i] = src[i];
	}
	
	static void rscan(int[] src, int[] dest){
		int i;
		dest[src.length-1]=src[src.length-1];
		for(i=src.length-2;i >=0 ; i--)
			dest[i]= dest[i+1]+ src[i];
	}
	
	
	static int reduce(int[] src){
		int i, dest;
		dest =0;
		for(i=0;i < src.length; i++)
			dest += src[i];
		return dest;
	}
	
	 public static void main(String[] str) {
		 
		 System.out.println("Int size:"+Integer.SIZE);
		 System.out.println("Long size:"+Long.SIZE);
		System.out.println("WordArrayAlgs");
		int nThreads = Runtime.getRuntime().availableProcessors();
		System.out.println(nThreads + " processors on this machine.");
		
		long startT =System.nanoTime();
		
		long endT = System.nanoTime();
		System.out.println("Nano timer has resolution of ns: "+ (endT-startT));
		startT =System.nanoTime();
		endT = System.nanoTime();
		System.out.println("Nano timer has resolution of ns: "+ (endT-startT));
		int test[] =     new int[5000000];
		int testDest[] = new int[5000000];
		int i;
		
		startT =System.nanoTime();
		Random rand = new Random();
		for(i=0;i<test.length;i++){
			test[i]= rand.nextInt();
		}
		System.arraycopy(test, 0, testDest, 0, test.length);
		endT = System.nanoTime();
		System.out.println("Random population has runtime of ns: "+ (endT-startT));
		System.out.println(((double)endT-(double)startT)/(1000000000) + " seconds");
		//////////////////////////////////
		
		
		
		
		
		
		///////////////////////////////////////
		 startT =System.nanoTime();
			for(i=0;i<TRIALS;i++){
				System.arraycopy(test, 0, testDest, 0, test.length);
				System.arraycopy(testDest, 0, test, 0, test.length);
			}
		
			endT = System.nanoTime();
			System.out.println("System.arraycopy() has runtime of ns: "+ (endT-startT));
			System.out.println(((double)endT-(double)startT)/(1000000000) + " seconds");
			//////////////////////////////////
			 startT =System.nanoTime();
				for(i=0;i<TRIALS;i++){
					System.arraycopy(test, 0, testDest, 0, test.length);
					System.arraycopy(testDest, 0, test, 0, test.length);
				}
			
				endT = System.nanoTime();
				System.out.println("System.arraycopy() has runtime of ns: "+ (endT-startT));
				System.out.println(((double)endT-(double)startT)/(1000000000) + " seconds");
				//////////////////////////////////
			
			 startT =System.nanoTime();
				for(i=0;i<TRIALS;i++){
					myArrayCopy(test,testDest);
					myArrayCopy(testDest, test);
				}
				endT = System.nanoTime();
				System.out.println("myArrayCopy has runtime of ns: "+ (endT-startT));
				System.out.println(((double)endT-(double)startT)/(1000000000) + " seconds");
				
			
			
			
			
			//////////////////////////////////
			startT =System.nanoTime();
			for(i=0;i<TRIALS;i++){
				Arrays.sort(test);
				System.arraycopy(testDest, 0, test, 0, test.length);
			}
			endT = System.nanoTime();
			System.out.println("Arrays.sort and arraycopy has runtime of ns: "+ (endT-startT));
			System.out.println(((double)endT-(double)startT)/(1000000000) + " seconds");
			
//////////////////////////////////
			
			
			startT =System.nanoTime();
			int j=0;
			for(i=0;i<TRIALS;i++){
				j+= Arrays.hashCode(test);
			}
			endT = System.nanoTime();
			System.out.println("sum Arrays.hashcode "+j+ " and arraycopy has runtime of ns: "+ (endT-startT));
			System.out.println(((double)endT-(double)startT)/(1000000000) + " seconds");
			
			
			
	
			
		//////////////////////////////////
		 startT =System.nanoTime();
		for(i=0;i<TRIALS;i++){
			scan(test,testDest);
			scan(testDest, test);
		}
		endT = System.nanoTime();
		System.out.println("Scan has runtime of ns: "+ (endT-startT));
		System.out.println(((double)endT-(double)startT)/(1000000000) + " seconds");
		
		/////////////////////////////////////
		
		 startT =System.nanoTime();
			for(i=0;i<TRIALS;i++){
				scan_unroll4(test,testDest);
				scan_unroll4(testDest, test);
			}
			endT = System.nanoTime();
			System.out.println("Scan_unroll4 has runtime of ns: "+ (endT-startT));
			System.out.println(((double)endT-(double)startT)/(1000000000) + " seconds");
			
		
		
		/////////////////////////////////////
		 startT =System.nanoTime();
			for(i=0;i<TRIALS;i++){
				rscan(test,testDest);
				rscan(testDest, test);
			}
			endT = System.nanoTime();
			System.out.println("rscan has runtime of ns: "+ (endT-startT));
			System.out.println(((double)endT-(double)startT)/(1000000000) + " seconds");
			
		
		
		
		/////////////////////////////////////////
		int accum =0;
		startT =System.nanoTime();
		for(i=0;i<TRIALS;i++){
			accum += reduce(test);
		}
		endT = System.nanoTime();
		System.out.println("Reduce has runtime of ns: "+ (endT-startT));
		System.out.println(((double)endT-(double)startT)/(1000000000) + "seconds");
		
		/*
		 * http://shootout.alioth.debian.org/u64q/program.php?test=knucleotide&lang=java&id=4
		 * */
		ExecutorService es = Executors.newFixedThreadPool(nThreads - 1);
		
		for (i = 0; i < nThreads; i++) {
		  
		      final Runnable task = new Runnable() {
		        @Override
		        public void run() {
		          //
		        }
		      };
		      if (i < nThreads - 1)
		        es.submit(task);
		      else
		        task.run();
		}
		try{
		 es.shutdown();
		 es.awaitTermination(1, TimeUnit.MINUTES);
		}
		catch (Exception e){
			e.printStackTrace();
		}
		
		System.out.println("DONE");
	}


	 
}
