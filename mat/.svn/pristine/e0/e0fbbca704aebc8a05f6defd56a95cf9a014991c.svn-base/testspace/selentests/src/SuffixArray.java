
import java.util.ArrayList;
import java.util.List;

public class SuffixArray {

	
	// Pang Ko's S(maller)L(arger)  array
	//The terminal character is always of type S
	List<Boolean> isSmallerList(List<Integer> input){	
		List<Boolean> retArr = new ArrayList<Boolean>();
		for(int i=0;i<input.size()-1;i++){
			if(input.get(i) < input.get(i+1))
				retArr.add(true);
		}
		retArr.add(true);
		return retArr;
	}
	
	
	//See DMM_SL_CONSTRUCTION.graphml for the distributed
	//memory version.
	
	
	
}
