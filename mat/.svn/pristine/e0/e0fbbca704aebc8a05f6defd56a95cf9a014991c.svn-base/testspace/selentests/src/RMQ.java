import java.util.List;

//Range Minimum query
public class RMQ<T extends Comparable<? super T>> {

	//The simple sqrt(n) solution.
	
	List<T> arr;
	List<T> mins;

	
	public RMQ(List<T> input){
		arr = input;
		double sqrtLenD = Math.sqrt(input.size());
		int sqrtLen = (int) Math.ceil(sqrtLenD);
		int rem = input.size() % sqrtLen;
		
		for(int i=0;i<arr.size()/sqrtLen;i++){
			T min = arr.get(i*sqrtLen);
			for(int j=1;j<sqrtLen;j++){
				if(min > arr.get(i*sqrtLen+j))
						min = arr.get(i*sqrtLen+j);
			}
			mins.add(min);
			}

		}
	}
	
	
	
	

	
	//lexicographic 101100 order
	
	//unordered tree to cannonical form
	
}


//succinct RMQ
//									[n/p] block size
//									Stored on all processors
//Macro RMQ for cross full block queries [min][min][min][min][min]
//Micro RMQ for an in block query
// 




/*Cartesian tree
 * 
 * 
 */


/*
Levocopoulous Peterson sort with cartesian trees
*
*/


/* Leftmost less than queries.
 * 
 * Given a range(a,b) and a key k, find the leftmost key that is less
 *  than k.
 *  
 *   Option 1) Walking an An ANSVL array.
 *   
 *   Option 2) Binary search with RMQ queries.
 */


*/