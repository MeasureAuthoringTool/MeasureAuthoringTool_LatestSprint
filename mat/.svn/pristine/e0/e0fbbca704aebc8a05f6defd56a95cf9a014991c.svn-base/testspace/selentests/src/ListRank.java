import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


public class ListRank {

	
	/* 5->7->6->9->6->5->5
	 * 
	 * 
	 */
	
	boolean isPermutation(List<Integer> list){
		Set<Integer> present = new HashSet<Integer>();
		for(int i=0;i<list.size();i++){
			if(list.get(i)<0 || list.get(i)>=list.size())
				return false;
			present.add(list.get(i));
		}
		if(present.size() != list.size())
			return false;
		return true;
	}
	
	boolean isListPermutation(List<Integer> list){
		if(!isPermutation(list))
			return false;
		Set<Integer> present = new HashSet<Integer>();
		Integer last =0;	
		for(int i=0;i<list.size();i++){
			present.add(last);
			last = list.get(last);
		}
		if(present.size() != list.size())
			return false;
		return true;
	}
	
	HashMap<Integer,Integer> rank(List<Integer> list){
		HashMap<Integer,Integer> ret = new HashMap<Integer,Integer>();
		Integer last =0;	
		for(int i=0;i<list.size();i++){
			ret.put(last,i);
			last = list.get(last);
		}
		
		return ret;
	}
	
	
}
