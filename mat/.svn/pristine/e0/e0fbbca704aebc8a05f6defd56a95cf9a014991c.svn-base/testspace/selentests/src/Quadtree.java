
public class Quadtree {

	//bit shuffle the coords
	//radix sort
	//compute i, i+1 similar prefixes (perhaps rounding to nearest cube)
	//All nearest largest values to determine parent
	//
	
	//compute local forces (adjacent, K-NN, box, sphere)
	//treewalk global forces
	
	
	//leaves @ depth[i]
	
	//permutation offsets between each iteration
	//Ave index change
	//RMSE index change
	
	
	
	
	// 1D quadtree to store interval endpoints
	// Radix sort the times
	// compute i, i+1 similar prefixes (perhaps rounding to nearest cube)
	// All nearest largest values to determine parent
	
	
	
}
