

import java.io.File;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.Augmenter;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;


public class SimpleSelenTest {

    /**
     * @param args
     */
	
	public static void takeScreenshot( WebDriver driver, String path){
	
	WebDriver augmentedDriver = new Augmenter().augment(driver);
    File screenshot = ((TakesScreenshot)augmentedDriver).getScreenshotAs(OutputType.FILE);
    try {
		FileUtils.copyFile(screenshot, new File(path));
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	}
    public static void main(String[] args) {
    	long startTime = System.currentTimeMillis();
    	
        // TODO Auto-generated method stub
        // Create a new instance of the Firefox driver
        // Notice that the remainder of the code relies on the interface,
        // not the implementation.
     
    	  WebElement mSearch;
        ArrayList<WebDriver> drivers = new ArrayList<WebDriver>();
        ArrayList<WebElement> userNames = new ArrayList<WebElement>();
        ArrayList<WebElement> passwords = new ArrayList<WebElement>();
        
       for(int i=0;i<200;i++){
    	   drivers.add( new FirefoxDriver());
    	   WebDriver driver = drivers.get(drivers.size()-1);
    	   driver.get(
    "https://nqfdev.telligen.org/Login.html");
    	   
        	WebElement userName = driver.findElement(By.id("E-mail Address"));
        	userName.sendKeys("cbrewbak@telligen.org");

        	WebElement password =  driver.findElement(By.id("Password"));
        	password.sendKeys("Welcome1#\n");
       
        /*	(new WebDriverWait(driver, 30)).until(new ExpectedCondition<WebElement>() {
        		public WebElement apply(WebDriver d) {
    		   return d.findElement(By.id("Search for a Measure"));
        		}
        	});*/
        	
        	System.out.println("Number "+i);
        	 try {
                 Thread.sleep(5000);
             } catch (InterruptedException e) {}
        	
        	continue;
        	/*
        	mSearch = driver.findElement(By.id("Search for a Measure"));
              
              mSearch.sendKeys("borkbork\n");
        	
        	mSearch = driver.findElement(By.className("logoutPanel"));
            mSearch.click();
            
       
       
        	// Check the title of the page
        	System.out.println("Page title is: " + driver.getTitle());      
        	//driver.quit();
			*/
        }
       
       
       //
     
        
       
     //  takeScreenshot(driver,"c:\\screenshot.png" );
        
        long endTime = System.currentTimeMillis();
        System.out.println("Test took "+(endTime-startTime)/1000.0+"seconds");
       // driver.quit();
    }
}