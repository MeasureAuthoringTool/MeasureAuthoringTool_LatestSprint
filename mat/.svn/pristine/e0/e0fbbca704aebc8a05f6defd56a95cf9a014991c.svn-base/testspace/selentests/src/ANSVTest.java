import java.util.ArrayList;
import java.util.List;


public class ANSVTest {

	
	
	//Corpus
	//[e,c,m,i][q,k,s,f][w,g,a,y][o,v,x,b][r,n,h,z][u,d,t,p][j,l]
	//ANSVL
	//[?,?,c,c][i,i,k,c][f,f,?,a][a,o,v,a][b,b,b,h][h,b,d,d][d,j]

	
    static final String corpus ="ecmiqksfwgayovxbrnhzudtpjl";
	static final String corpus_ansvl = "??cciikcff?aaovabbbhhbdddj";
    static List<Integer> corpusAsInt;
	
	
	static List<Integer> corpusToInt(String corpus){
		List<Integer> ints = new ArrayList<Integer>();
		for(int i=0;i<corpus.length(); i++){
			ints.add((int) corpus.charAt(i));
		}
		return ints;
	}
	
	
	public static List<Integer> reverse(List<Integer> a){
		List<Integer> newA = new ArrayList<Integer>();
		while(a.size()>0){
			newA.add(a.get(a.size()-1));
			a.remove(a.size()-1);
		}
		return newA;
	}
	
	
	public boolean isPalindromeAnagram(String   s){
		//assuming this is initalized to zero
		boolean  bvec[] = new boolean[90];
		// ' ' is ASCII 32
		// 'z' is ASCII 122
		// So -32 to base at zero and length 90
		for(int i=0;i<s.length();i++){
			bvec[(int)s.charAt(i)-32] ^= true;
		}
		int odds =0;
		for(int i=0;i<90;i++){
			if(bvec[i]){
				odds++;
				if(odds>1)
					return false;
			}
		}
		return true;
	}
	
	
	 public static void main(String[] args) {
		 
		 ANSV<Integer> ansvUtil = new ANSV<Integer>();
		 corpusAsInt = corpusToInt(corpus);
		 
		 List<Integer> answer =ansvUtil.ansvl(corpusAsInt);
		 
		for(int a: corpusAsInt)
			System.out.println((char) a);
		 
		System.out.println("-----");
		for(Integer a: answer){
			if(a != null)
				System.out.print((char) (int)a);
			else 
				System.out.print("?");
		}
		
		answer =ansvUtil.ansvr(corpusAsInt);
		answer = reverse(answer);
		System.out.println("\n-----ANSVR-----");
		for(Integer a: answer){
			if(a != null)
				System.out.print((char) (int)a);
			else 
				System.out.print("?");
		}
		 System.out.println("\nDone.");
		 return;

		 
	 }
	
	
}
