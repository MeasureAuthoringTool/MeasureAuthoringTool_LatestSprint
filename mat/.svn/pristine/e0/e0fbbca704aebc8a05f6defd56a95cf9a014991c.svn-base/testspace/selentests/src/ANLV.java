import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

//All nearest larger values
// needed for framework construction in Bern Epstein Teng, 
//Parallel construction of quadtrees and quality triangulations 
public class ANLV<T extends Comparable<? super T>> {

	public List<T> anlvl(List<T>in ){
		 List<T> out = new ArrayList<T>();
		 Stack<T> st = new Stack<T>();
		 for(T i: in){
			 while(!st.empty() && st.peek().compareTo(i) <= 0){
				 st.pop();
			 }
			 if(st.empty())
				 out.add(null);
			 else
				 out.add(st.peek());
			 st.push(i);
		 }
		 return out;
	}
	
	public List<Integer> anlvl_index(List<T>in ){
		 List<Integer> out = new ArrayList<Integer>();
		 Stack<T> st = new Stack<T>();
		 Stack<Integer> st_index = new Stack<Integer>();
		 for(int i=0;i<in.size();i++){
			 while(!st.empty() && st.peek().compareTo(in.get(i))<=0){
				 st.pop();
				 st_index.pop();
			 }
			 if(st.empty())
				 out.add(null);
			 else
				 out.add(st_index.peek());
			 st.push(in.get(i));
			 st_index.push(i);
		 }
		 return out;
	}
	
	
	
}
