

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class SeleniumBenchmark {
	private WebDriver driver;
	private String baseUrl="";
	private StringBuffer verificationErrors = new StringBuffer();
	@Before
	public void setUp() throws Exception {
		driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@Test
	public void testSeleniumBenchmark() throws Exception {
		driver.get("https://nqfdev.ifmc.org/Login.html");
		driver.findElement(By.id("E-mail Address")).clear();
		driver.findElement(By.id("E-mail Address")).sendKeys("cbrewbak@telligen.org");
		driver.findElement(By.id("Password")).clear();
		driver.findElement(By.id("Password")).sendKeys("Welcome1#");
		driver.findElement(By.cssSelector("button.primaryButton")).click();
		driver.findElement(By.linkText("All")).click();
		driver.findElement(By.linkText("Andrew Schmidt's 494th Dream")).click();
		
	
		driver.findElement(By.xpath("//table[@id='measureComposerTabLayout']/tbody/tr/td/table/tbody/tr/td[3]/div/div")).click();
		//driver.findElement(By.)
		driver.findElement(By.linkText("All")).click();
		driver.findElement(By.xpath("//table[@id='measureComposerTabLayout']/tbody/tr/td/table/tbody/tr/td[4]/div/div")).click();
		driver.findElement(By.cssSelector("table.tabPanel > tbody > tr > td > table.gwt-TabBar > tbody > tr > td.gwt-TabBarItem-wrapper > div.gwt-TabBarItem > div.gwt-HTML")).click();
		driver.findElement(By.xpath("//table[@id='criterionPanel']/tbody/tr/td/table/tbody/tr/td[3]/div/div")).click();
		driver.findElement(By.xpath("//table[@id='criterionPanel']/tbody/tr/td/table/tbody/tr/td[4]/div/div")).click();
		driver.findElement(By.xpath("//table[@id='criterionPanel']/tbody/tr/td/table/tbody/tr/td[5]/div/div")).click();
		driver.findElement(By.xpath("//table[@id='criterionPanel']/tbody/tr/td/table/tbody/tr/td[6]/div/div")).click();
		driver.findElement(By.xpath("//table[@id='criterionPanel']/tbody/tr/td/table/tbody/tr/td[7]/div/div")).click();
		driver.findElement(By.xpath("//table[@id='criterionPanel']/tbody/tr/td/table/tbody/tr/td[8]/div/div")).click();
		driver.findElement(By.xpath("//table[@id='criterionPanel']/tbody/tr/td/table/tbody/tr/td[9]/div/div")).click();
		driver.findElement(By.xpath("//table[@id='criterionPanel']/tbody/tr/td/table/tbody/tr/td[10]/div/div")).click();
		driver.findElement(By.xpath("//table[@id='criterionPanel']/tbody/tr/td/table/tbody/tr/td[11]/div/div")).click();
		//driver.findElement(By.linkText("Sign Out")).click();
	}

	@After
	public void tearDown() throws Exception {
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}
}
