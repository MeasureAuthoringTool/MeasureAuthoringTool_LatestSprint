
public class MortonUtility {
	
	public boolean[] interleave3_32(boolean[] vec){
		boolean[] ret =  new boolean[32*3];

		for(int i=0;i<32;i++){
			ret[(i*3)] = vec[i];
			ret[(i*3)+1] = vec[32+i];
			ret[(i*3)+2] = vec[64+i];
		}
		return ret;
	}
	
	
	public int samePrefix( boolean[] vecA,  boolean[] vecB, int size){
		for(int i=0;i<size;i++){
			if(vecA[i] != vecB[i])
				return i;
		}
		return size;
	}
	
	public boolean[] deInterleave3_32(boolean[] vec){
		boolean[] ret =  new boolean[32*3];
		
		int count =0;

		for(int i=0;i<32;i++){
			ret[count] = vec[i*3];
			count++;
		}
		for(int i=0;i<32;i++){
			ret[count] = vec[(i*3)+1];
			count++;
		}
		for(int i=0;i<32;i++){
			ret[count] = vec[(i*3)+2];
			count++;
		}
		return ret;
	}
	
	
}
