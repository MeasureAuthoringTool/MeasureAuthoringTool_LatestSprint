				/* Add Kaiser Permanente to the beta users list */
	            INSERT INTO MAT_APP.STEWARD_ORG VALUES ('84', 'Kaiser Permanente','');
				INSERT INTO MAT_APP.AUTHOR VALUES ('85', 'Kaiser Permanente');